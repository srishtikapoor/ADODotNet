insert into Product values('Garnier Men Facewash', 115, 25);
select * from Product;